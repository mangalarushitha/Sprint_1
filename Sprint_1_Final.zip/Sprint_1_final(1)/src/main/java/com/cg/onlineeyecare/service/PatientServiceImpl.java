 package com.cg.onlineeyecare.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

import com.cg.onlineeyecare.dao.AppointmentRepository;
import com.cg.onlineeyecare.dao.PatientRepository;
import com.cg.onlineeyecare.dto.Appointment;
import com.cg.onlineeyecare.dto.Patient;
import com.cg.onlineeyecare.dto.Report;
import com.cg.onlineeyecare.exceptions.AppointmentIdNotFoundException;
import com.cg.onlineeyecare.exceptions.PatientIdFoundNotException;
import com.sun.xml.bind.v2.schemagen.xmlschema.Import;

import java.util.Optional;
/****************************
*          @author          Rushitha
*          Description      It is a patient service implementation class that defines the methods
*                           mentioned in its interface.
 *         Version             1.0
 *         Created Date     25-MARCH-2021
****************************/
@Service
public  class PatientServiceImpl implements PatientService{
	@Autowired
	private PatientRepository patientRepo;
	@Autowired
	private AppointmentRepository appointmentDao;
	/****************************
	 * Method:                          addPatient
     *Description:                      It is used to add patient into patient table
     * @param patient:                     Patient's reference variable.
	 * @returns patient                    It returns patient with details
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ****************************/
	@Override
	public Patient addPatient(Patient patient) {
		// TODO Auto-generated method stub
		return patientRepo.saveAndFlush(patient);
		//return null;
	}
	/****************************
	 * Method:                          updatePatient
     *Description:                      It is used to update patient details into patient table.
     * @param patient:                     patient's reference variable.
	 * @returns patient                    It returns updated details of the existed patient.
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ****************************/
	@Override
	public Patient updatePatient(Patient patient) {
		// TODO Auto-generated method stub
		return patientRepo.save(patient);
		
	}
	/****************************
	 * Method:                          deletePatiet
     *Description:                      It is used to delete patient
     *@param patient:                      patient's reference variable.
	 * @returns patient                    It returns the patient that has been deleted
	 * @throws PatientIdFoundNotException: It is raised due to invalid patient.
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ****************************/
	@Override
	public Patient deletePatient(int patientId) throws PatientIdFoundNotException {
		// TODO Auto-generated method stub
	Optional<Patient> result=patientRepo.findById(patientId);
		if(result.isPresent())
		{
			patientRepo.deleteById(patientId);
			return  result.get();
		}
		else
		{
			throw new PatientIdFoundNotException("please enter valid patient id");
		}
	}
	/****************************
	 * Method:                          viewAllPatients
     *Description:                      To display all the patients
	 * @returns List<patient>            - It returns all the patients present in database
     *Created By                      - Rushitha
     *Created Date                     - 25-MARCH-2021                           
	 
	 ****************************/
	@Override
	public List<Patient> viewPatientList() {
		// TODO Auto-generated method stub
		return patientRepo.findAll();
	}
	/****************************
	 * Method:                          viewPatient
     *Description:                      To display the patient by Id (Primary key)
     *@param id:                        id of the patient.
	 * @returns patient                 - if patient with Id presents it returns test else throws PatientIdFoundNotException
	 * @throws PatienttIdNotFoundException  -  It is raised due to invalid  PatientId 
     *Created By                      - Rushitha
     *Created Date                    - 25-MARCH-2021                           
	 
	 ****************************/
	@Override
	public Patient viewPatient(int patientId) throws PatientIdFoundNotException {
		// TODO Auto-generated method stub
		java.util.Optional<Patient> result=patientRepo.findById(patientId);
		if(result.isPresent())
		{
			patientRepo.findById(patientId);
			return  result.get();
		}
		else
		{
			throw new PatientIdFoundNotException("please enter valid patient id");
		}
	}
	
	/****************************
	 * Method:                          localDate
     *Description:                      To display all the patient DOB
	 * @returns patientDOB            - It returns patient DOB present in database
     *Created By                      - Rushitha
     *Created Date                     - 25-MARCH-2021                           
	 
	 ****************************/
	
	@Override
	public Appointment bookAppointments(Appointment appointment) {
		 //TODO Auto-generated method stub
		return appointmentDao.saveAndFlush(appointment);
      }

	@Override
	public Appointment viewAppointmentDetails(int appointmentId) throws AppointmentIdNotFoundException {
		// TODO Auto-generated method stub
		//return null;
		//return  appointmentRepo.findById(appointmentId).get();
		Optional<Appointment> result=appointmentDao.findById(appointmentId);
		if(result.isPresent())
		{
			return result.get();
		}
		else
		{
			throw new AppointmentIdNotFoundException("please enter valid appointment id");
		}
	}
}

	
	
