package com.cg.onlineeyecare.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineeyecare.dto.User;
import com.cg.onlineeyecare.exceptions.PasswordNotMatchException;
import com.cg.onlineeyecare.exceptions.UserNotFoundException;
import com.cg.onlineeyecare.service.IUserService;

import io.swagger.annotations.Api;
/***********************************************************
 * @author              P.saiteja reddy
 * Description          It is a controller class that controls the data flow into model object 
 *                      and updates the view whenever data changes
 * Version              1.0
 * created date         24-03-2021
 */
@Api(value = "Swagger2DemoRestController")
@RestController
@RequestMapping("/V1")
public class UserController {
	@Autowired
	private IUserService Iuserserice;
	/*****************************************************
	 * Method              defaultResponse
	 * Description         displays the website application name
	 * @Getmapping         It is used to handle GET type of request method.
	 * Created by:         P.saiteja reddy
	 * created date        24-03-2021
	 *****************************************************/
	@GetMapping("/")
	public String defaultResponse() {
		return "Welcome to Online Eye Clinic Application";
		
	}
	/****************************************************************************
	 * Method                         loginUser
	 * Description                    It is used to login into online application
	 * @param user                    user reference variable
	 * @return                        return true if user details is correct or else false
	 * @throws UserNotFoundException  it is raises due to invalid user details
	 */
	@PostMapping("/login")
	public ResponseEntity<Boolean> loginUser(@RequestBody User user) throws UserNotFoundException{
		return new ResponseEntity<Boolean>(Iuserserice.signIn(user),HttpStatus.OK);
	}
	/*******************************************************************************
	 * Method                        logoutUser
	 * Description                   It is used to logout from online application
	 * @param user                   user reference variable
	 * @return                       true if user details are correct
	 * @throws UserNotFoundException It raises due to invalid user details
	 */
	@PostMapping("/logout")
	public ResponseEntity<Boolean> logoutUser(@RequestBody User user) throws UserNotFoundException{
		return new ResponseEntity<Boolean>(Iuserserice.signOut(user),HttpStatus.OK);	
	}
	/*******************************************************************************
	 * Method                        updatePassword
	 * Description                   It is used to update the password
	 * @param user                   user reference variable
	 * @return                       It will update the password by checking with old password
	 * @throws UserNotFoundException It raises due to invalid details
	 */
	
	@PutMapping("/updatepassword/{newPassword}")
	public ResponseEntity<User> updatePassword(@PathVariable String newPassword,@RequestBody User user) throws UserNotFoundException, PasswordNotMatchException{
		return new ResponseEntity<User>(Iuserserice.changePassword(newPassword, user),HttpStatus.OK);
	}
}
