package com.cg.onlineeyecare.service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Optional;
import javax.swing.text.DateFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlineeyecare.dao.AppointmentRepository;
import com.cg.onlineeyecare.dto.Appointment;
import com.cg.onlineeyecare.exceptions.AppointmentIdNotFoundException;
import com.cg.onlineeyecare.exceptions.InvalidAppointmentException;

/************************************************************************************
 *          @author          K NAGA VAISHNAVI
 *          Description      It is a test service implementation class that defines the methods
 *                           mentioned in its interface.
 *         Version             1.0
 *         Created Date     22-MARCH-2021
 ************************************************************************************/
@Service
public class AppointmentServiceImpl implements AppointmentService{
	@Autowired
	AppointmentRepository appointmentRepo;
	/************************************************************************************
	 * Method:                          bookAppointment
     *Description:                      It is used to book appointment into appointment table
     * @param appointment:              appointment's reference variable.
	 * @returns appointment             It returns appointmet with details
     *Created By                      - K NAGA VAISHNAVI
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	@Override
	public Appointment bookAppointment(Appointment appointment) {
		// TODO Auto-generated method stub
		
		return appointmentRepo.saveAndFlush(appointment);
	}
	/************************************************************************************
	 * Method:                          updateAppointment
     *Description:                      It is used to update appointment details into appointment table.
     * @param appointment:              appointment's reference variable.
	 * @returns appointment             It returns updated details of the existed appointment.
     *Created By                      - K NAGA VAISHNAVI
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	@Override
	public Appointment updateAppointment(Appointment appointment) throws InvalidAppointmentException {
		// TODO Auto-generated method stub
		Optional<Appointment> result=appointmentRepo.findById(appointment.getAppointmentId());
		if(result.isPresent())
		{
			return appointmentRepo.saveAndFlush(appointment);
		}
		else
		{
			throw new InvalidAppointmentException("please enter valid appointment id");
		}
	}
	/************************************************************************************
	 * Method:                          cancelApppointment
     *Description:                      It is used to cancel appointment
     *@param appointment:               appointment's reference variable.
	 * @returns appointment                    It returns the appointment that has been canceled
	 * @throws AppointmentIdNotFoundException: It is raised due to invalid appointment id.
     *Created By                      - K NAGA VAISHNAVI
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	@Override
	public Appointment cancelAppointment(int appointmentId) throws AppointmentIdNotFoundException {
		// TODO Auto-generated method stub
		Optional<Appointment> result=appointmentRepo.findById(appointmentId);
		if(result.isPresent())
		{
			appointmentRepo.deleteById(appointmentId);
			return result.get();
		}
		else
		{
			throw new AppointmentIdNotFoundException("please enter valid appointment id");
		}
		
	}
	/************************************************************************************
	 * Method:                          viewAppointment
     *Description:                      To display the appointment by Id (Primary key)
     *@param appointmentId:                        id of the appointment.
	 * @returns test                  - if appointment with Id presents it returns appointment else throws AppointmentIdNotFoundException
	 * @throws AppointmentIdNotFoundException  -  It is raised due to invalid  Appointment Id 
     *Created By                      - K NAGA VAISHNAVI
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	@Override
	public Appointment viewAppointment(int appointmentId) throws AppointmentIdNotFoundException {
		// TODO Auto-generated method stub
		Optional<Appointment> result=appointmentRepo.findById(appointmentId);
		if(result.isPresent())
		{
			appointmentRepo.findById(appointmentId);
			return result.get();
		}
		else
		{
			throw new AppointmentIdNotFoundException("please enter valid appointment id");
		}
	}
	/************************************************************************************
	 * Method:                          viewAllAppointments
     *Description:                      To display all the appointments
	 * @returns List<Appointment>      - It returns all the appointments present in database
     *Created By                       - K NAGA VAISHNAVI
     *Created Date                     - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	@Override
	public List<Appointment> viewAllAppointments() {
		// TODO Auto-generated method stub
		return appointmentRepo.findAll();
	}

	/************************************************************************************
	 * Method:                          viewAppointments
     *Description:                      To display the appointment by date
	 * @returns appointments          - if appointment on that day is present it returns the particular date appointments.  
     *Created By                      - K NAGA VAISHNAVI
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	@Override
	public List<Appointment> viewAppointments(LocalDate date) {
		// TODO Auto-generated method stub
		return appointmentRepo.findAll().stream().filter(app->(date.compareTo(app.getDateOfAppointment())==0)).collect(Collectors.toList());
	}
	
}
