package com.cg.onlineeyecare.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.onlineeyecare.dto.User;
/***************************************************************
 * @author              P.saiteja reddy
 * Description          It is a test repository interface that extends jpa repository 
 *                      that contains inbuilt methods for various operations
 * Version              1.0
 * created date         24-03-2021
 *
 ****************************************************************/
public interface IUserRepository extends JpaRepository<User,Integer>{
	Optional<User> findByuserName(String name);
}
