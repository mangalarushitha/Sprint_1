package com.cg.onlineeyecare.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineeyecare.dto.Appointment;
import com.cg.onlineeyecare.exceptions.AppointmentIdNotFoundException;
import com.cg.onlineeyecare.exceptions.InvalidAppointmentException;
import com.cg.onlineeyecare.service.AppointmentService;

import io.swagger.annotations.*;
/************************************************************************************
 *          @author          K NAGA VAISHNAVI
 *          Description      It is a Controller class ie,used for the data flow into model object 
 *                           and updates the view whenever data changes
  *         Version             1.0
  *         Created Date    22-MARCH-2021
 ************************************************************************************/
@Api(value = "Swagger2DemoRestController")
@RestController
@RequestMapping("/v1")
public class AppointmentController {
	@Autowired
	AppointmentService appointmentRepo;
	
	/************************************************************************************
	 * Method:                          bookAppointment
     *Description:                      To book the appointment
	 * @returns List<Appointment>     - It returns appointment details  in database
	 * @PostMapping:                  - It is used to handle Post type of request method.
	 * @RequestBody:                  - It maps the HttpRequest body to a transfer or domain object
     *Created By                      - K NAGA VAISHNAVI
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/

	@PostMapping("/bookappointment")
	public Appointment bookAppointment(@RequestBody Appointment appointment) {
		return appointmentRepo.bookAppointment(appointment);
	}
	/************************************************************************************
	 * Method:                          updateAppointment
     *Description:                      It is used to update appointment details into appointment table.
     * @param appointment:              Appointment's reference variable.
	 * @returns appointment             It returns updated details of the existed appointment.
	 * @throws InvalidappointmentException     It is raised due to invalid appointment
	 * @PuttMapping:                    It  is used to handle PUT type of request method
	 * @RequestBody:                    It maps the HttpRequest body to a transfer or domain object
     *Created By                    -   K NAGA VAISHNAVI
     *Created Date                  -   22-MARCH-2021                           
	 
	 ************************************************************************************/

	@PutMapping("/updateappointment")
	public Appointment updateAppointment(@RequestBody Appointment appointment) throws InvalidAppointmentException {
		return appointmentRepo.updateAppointment(appointment);
	}
	/************************************************************************************
 	 * Method:                           cancelAppointment
      *Description:                      It is used to cancel appointment
      *@param id:                        id of the appointment.
      *@param appointment:                      appointment's reference variable.
 	 * @returns appointment                     It returns the appointment that has been canceled
 	 * @throws AppointmentIdNotFoundException:  It is raised due to invalid appointmentId.
 	 * @DeleteMapping:                   It  is used to handle DELETE type of request method.
 	 * @RequestBody:                     It maps the HttpRequest body to a transfer or domain object
     *Created By                       - K NAGA VAISHNAVI
     *Created Date                     - 22-MARCH-2021                           
 	 
 	 ************************************************************************************/

	@DeleteMapping("/cancelappointment/{id}")
	public Appointment cancelAppointment(@PathVariable int id) throws AppointmentIdNotFoundException {
		return appointmentRepo.cancelAppointment(id);
	}
	/************************************************************************************
	 * Method:                          viewAllAppointments
     *Description:                      To display all the appointments
	 * @returns List<Appointment>     - It returns all the appointments present in database
	 * @GetMapping:                     It is used to handle GET type of request method.
     *Created By                      - K NAGA VAISHNAVI
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/

	@GetMapping("/viewallappointments")
	public List<Appointment> listallappointments() {
		return appointmentRepo.viewAllAppointments();
	}
	  /************************************************************************************
		 * Method:                          viewAppointment
	     *Description:                      To display the appointment by Id (Primary key)
	     *@param id:                        id of the appointment.
		 * @returns appointment                 - if appointment with Id presents it returns appointment else throws AppointmentIdNotFoundException
		 * @throws AppointmentIdNotFoundException  - It is raised due to invalid  appointmentId 
		 * @GetMapping:                     It is used to is used to handle GET type of request method.
		 * @PathVariable:                   It  is used for data passed in the URI and transfer its values to parameter variables.
	     *Created By                      - K NAGA VAISHNAVI
	     *Created Date                    - 22-MARCH-2021                           
		 
		 ************************************************************************************/
	@GetMapping("/viewappointment/{id}")
	public Appointment viewAppointment(@PathVariable int id) throws AppointmentIdNotFoundException {
		return appointmentRepo.viewAppointment(id);
	}
	
	/************************************************************************************
	 * Method:                          viewAppointments
     *Description:                      To display the appointment by date
     *@param date:                        date of the day
	 * @returns appointments          - if appointment on that day is present it returns the particular date appointments.  
	 * @GetMapping:                     It is used to is used to handle GET type of request method.
	 * @RequestParam:                 - contains the request data and provides it to view page.
	 * @DateTimeFormat                - method parameter should be formatted as a date or time.
     *Created By                      - K NAGA VAISHNAVI
     *Created Date                    - 22-MARCH-2021                           
	 
	 ************************************************************************************/
	@GetMapping("/viewallappointmentbydate")
	public List<Appointment> listallappointments(@RequestParam(value="date")@DateTimeFormat(iso=DateTimeFormat.ISO.DATE)LocalDate date) {
		return appointmentRepo.viewAppointments(date);
	}

}
