package com.cg.onlineeyecare.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "User_Table1")
public class User {
	@Id
	private String userName;
	private String password;
	private String role;
	
	public String getUserName() {
		return userName;
	}	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}	
	public void setPassword(String password) {
		this.password = password;
	}	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	/************************************************************************************
	 * Method:                          User
     *Description:                      It is used to initialize the empty constructor.
     *Created By                      - p.saiteja reddy
     *Created Date                    - 24-MARCH-2021  */
	public User() {
		super();
	}
	/************************************************************************************
	 * Method:                                 User
     *Description:                             It is used to initialize the parameterized constructor.
     *@param username:                         user name 
     *@param password:                         user password 
     *@param role:                             user role 
     *Created By                            -  p.saitejareddy
     *Created Date                          -  24-MARCH-2021                           
	 
	 ************************************************************************************/
	public User(String userName, String password, String role) {
		super();
		this.userName = userName;
		this.password = password;
		this.role = role;
	}
	

}
