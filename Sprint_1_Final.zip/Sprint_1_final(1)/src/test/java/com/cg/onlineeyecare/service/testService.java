package com.cg.onlineeyecare.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import com.cg.onlineeyecare.dto.test;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.onlineeyecare.exceptions.TestIdNotFoundException;
import com.cg.onlineeyecare.service.ITestService;

@SpringBootTest
public class testService {
	@Autowired
	ITestService service;

	@Test
	void addtest() throws TestIdNotFoundException {
		test ts2 = new test(123, "hjh", "leg broken", "X-ray", 145.2);
		service.addTest(ts2);
		assertEquals("X-ray", service.viewTest(123).getTestDescription());
	}

	@Test
	void romovetest() throws TestIdNotFoundException {
		assertEquals(123, service.removeTest(123).getTestId());
	}

	@Test
	void viewtest() throws TestIdNotFoundException {
		assertEquals("Retinoscopy", service.viewTest(126).getTestName());
	}

	@Test
	void viewalltest() {
		assertEquals("Laser", service.viewAllTests().get(0).getTestType());
	}

	@Test
	void updatetest() throws TestIdNotFoundException {
		test test1 = new test(126, "Retinoscopy", "Laser", "-1.50 cylinder", 453.67);
		service.updateTest(test1);
		assertEquals("Laser", service.viewTest(121).getTestType());
	}
}
