package com.cg.onlineeyecare.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.onlineeyecare.dto.Doctor;
import com.cg.onlineeyecare.dto.test;
import com.cg.onlineeyecare.exceptions.DoctorIdNotFoundException;
import com.cg.onlineeyecare.exceptions.TestIdNotFoundException;
import com.cg.onlineeyecare.service.IDoctorServiceImpl;
@SpringBootTest
class IDoctorServiceTest {
	@Autowired
	IDoctorServiceImpl iDoctorService;
//	@Test
//	void addDoctorTest() throws DoctorIdNotFoundException {
//		Doctor doc1=new Doctor(12,"Madhuri","10:46",989789,"madh123@gmail.com","mad1","madh12","chennai", null);
//		assertEquals("Madhuri", iDoctorService.addDoctor(doc1).getDoctorName());
//	}

	
//	@Test
//	void updateDoctor() throws DoctorIdNotFoundException {
//		Doctor test1 = new Doctor(12,"Mad","10:46",989789,"madh123@gmail.com","madi","madh12","chennai", null);
//		//iDoctorService.updateDoctor(test1);
//		assertEquals("Mad", iDoctorService.updateDoctor(test1).getDoctorName());
//	}
//	
	@Test
	void viewDoctorsList() {
		assertEquals(1, iDoctorService.viewDoctorsList().get(0).getDoctorId());
	}
	
	@Test
	void viewDoctor() throws DoctorIdNotFoundException {
		Doctor doc2=new Doctor(15,"Maya","11:13",9789,"maya123@gmail.com","may1","maya12","chennai");
		iDoctorService.addDoctor(doc2);
		assertEquals("11:13", iDoctorService.viewDoctor(15).getDoctorConsultationTime());
	}
//	@Test
//	void deleteDoctor()
//	{
//		Doctor doc3=new Doctor(18,"shylu","11:14",99,"shylu123@gmail.com","sah1","shyl12","chennai");
//		iDoctorService.addDoctor(doc3);
//		assertEquals(18, iDoctorService.deleteDoctor(18).getDoctorId());
//	}
   
	@Test
	void createTest() throws TestIdNotFoundException {
		test ts2 = new test(123, "hjh", "leg broken", "X-ray", 145.2);
		assertEquals("X-ray", iDoctorService.createTest(ts2).getTestDescription());
	}
	

      
}