package com.cg.onlineeyecare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Appointment1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
